import { Dimensions, Platform, StyleSheet } from 'react-native';
const { width } = Dimensions.get('window');


const globalStyles = StyleSheet.create({
  Globalcontainer: {
    display: "flex",
    alignSelf: "center",
    width: "100%",
  },
  container: {
    padding: 20,
    backgroundColor: "#fff",
    maxWidth: "600px",
    margin: "0 auto",
    marginLeft: 10,
    display:"flex",
  },
  title: {
    textAlign: "center",
    marginBottom: 10,
    fontSize: 18,
    fontWeight: "bold",
  },
  label: {
    marginTop: 10,
    marginBottom: 5, // corregido: era "5px", debe ser número
    fontSize: 14,
    color: "#333",
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 8,
    backgroundColor: "#D9D9D9",
    marginBottom: 10,
    borderRadius: 4,
    fontSize: 14,
    width: 320,
    height: 32,
  },
  inputtorre: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 8,
    backgroundColor: "#D9D9D9",
    marginBottom: 10,
    borderRadius: 4,
    fontSize: 14,
    width: 80,
    height:32,
  },
  inputapto: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 8,
    backgroundColor: "#D9D9D9",
    marginBottom: 10,
    borderRadius: 4,
    fontSize: 14,
    width: 80,
    height:32,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",

  },
  inputsTorres: {
    display: "flex"
  },
  halfInputContainer: {
    display: "flex",
    flex: 1,
    marginHorizontal: 5,
    flexDirection:"row",
    gap:10
  },
  checkboxContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10
  },
  checkbox: {
    width: 20,
    height: 20,
    borderWidth: 1,
    borderColor: "#000",
    marginRight: 5,
    justifyContent: "center",
    alignItems: "center" 
  },
  checkboxChecked: {
    width: 12,
    height: 12,
    backgroundColor: "#007bff"
  },
  checkboxLabel: {
    flex: 1,
    fontSize: 12,
    color: "#555"
  },
  button: {
    flex: 1,
    padding: 10,
    marginHorizontal: 5,
    borderRadius: 4,
    alignItems: "center",
    justifyContent:"center"
  },
  buttonGrey: {
    backgroundColor: "#ccc",
    width:148,
    height:28,
  },
  buttonBlue: {
    backgroundColor: "#007bff",
    marginBottom:10,
    width:148,
    height:28,
  },
  buttonText: {
    fontSize: 14,
  },
  buttonTextWhite: {
    color: "#fff"
  },
  profileImage: {
    width: 120,
    height: 120,
    borderRadius: 60, // esto lo hace circular
    alignSelf: "center", // centra horizontalmente
    marginBottom: 15,
    borderWidth: 2,
    borderColor: "#007bff", // o el color que desees del prototipo
  },
//login
globalContainerLogin: {
  flex: "100%",
  width: "100%",
  maxWidth: 600,
  padding: 20,
  backgroundColor: "#fff",
  justifyContent: 'space-evenly',

},
text:{
  fontSize: 14,
  color: "#333",
  marginLeft:20,
},

  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: "#d9d9d9",
    marginBottom: 30,
    alignSelf:"center",
  },
  inputLogin: {
    backgroundColor: "#d9d9d9",
    width: 320,
    height: 32,
    padding: 10,
    borderRadius: 5,
    marginBottom: 15,
    alignSelf:"center",
  },
  passwordInputLogin: {
    backgroundColor: "#d9d9d9",
    width: 320,
    height: 32,
    padding: 10,
    borderRadius: 5,
    marginBottom: 15,
    alignSelf:"center",
  },
  eyeIconLogin: {
    width: 24,
    height: 24,
    tintColor: "#888",
  },
  forgotTextLogin: {
    alignSelf: "flex-end",
    color: "#3578e5",
    marginBottom: 25,
    marginRight:20,
  },
  buttonBlueLogin: {
    backgroundColor: "#3578e5",
    width: 334,
    height:32,
    padding: 12,
    borderRadius: 5,
    alignSelf:"center",
    alignItems: "center",
    justifyContent:"center",
    marginBottom: 40,
  },
  buttonTextLogin: {
    fontSize: 16,
  },
  buttonTextWhiteLogin: {
    color: "#fff",
  },
  registerTextLogin: {
    fontSize: 14,
    color: "#333",
    alignSelf:"center",
  },
  registerLinkLogin: {
    color: "#3578e5",
  },

//verificacion correo
containerC: {
  flex: 1,
  padding: 30,
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: '#fff',
},
logoC: {
  width: 100,
  height: 100,
  marginBottom: 30,
  resizeMode: 'contain',
},
textC: {
  fontSize: 16,
  textAlign: 'center',
  marginBottom: 15,
  color: '#333',
},
emailC: {
  fontWeight: 'bold',
},
resendTextC: {
  marginTop: 10,
  fontSize: 14,
  color: '#333',
},
resendLinkC: {
  color: '#1E90FF',
},
buttonContainerC: {
  flexDirection: 'row',
  marginTop: 40,
  justifyContent: 'space-between',
  width: '100%',
  paddingHorizontal: 20,
},
backButtonC: {
  flex: 1,
  paddingVertical: 12,
  borderWidth: 1,
  borderColor: '#1E90FF',
  borderRadius: 8,
  marginRight: 10,
  alignItems: 'center',
},
backTextC: {
  color: '#1E90FF',
  fontWeight: 'bold',
},
continueButtonC: {
  flex: 1,
  paddingVertical: 12,
  backgroundColor: '#1E90FF',
  borderRadius: 8,
  marginLeft: 10,
  alignItems: 'center',
},
continueTextC: {
  color: '#fff',
  fontWeight: 'bold',
},
imagencarga:{
  alignSelf:"center",
  marginTop:"60%",
},
homeContainer: {
  flex: 1,
  backgroundColor: '#F2F2F2',
  width: '100%',        // que llene hasta su tope
  maxWidth: 400,        // aquí defines el ancho máximo (ajústalo a tu gusto)
  alignSelf: 'center',  // lo centra horizontalmente en pantallas grandes
  paddingBottom: 20,  

},
// Header
header: {
  backgroundColor: '#3A81F7',
  paddingVertical: 12,
  alignItems: 'center',
  justifyContent: 'center',
  ...Platform.select({
    ios: { paddingTop: 40 },
    android: { paddingTop: 20 },
  }),
},
headerText: {
  color: '#FFFFFF',
  fontSize: 20,
  fontWeight: '600',
},

// Section wrapper
sectionContainer: {
  marginHorizontal: 16,
  marginTop: 24,
},
sectionTitle: {
  fontSize: 18,
  fontWeight: '500',
  color: '#333333',
  marginBottom: 8,
},

// Card
card: {card: {
  backgroundColor: '#FFFFFF',
  borderRadius: 12,
  padding: 16,
  flexDirection: 'row',
  alignItems: 'center',

  // Para simular ancho de móvil y centrar en desktop
  width: '100%',
  maxWidth: 360,
  alignSelf: 'center',

  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.1,
  shadowRadius: 4,
  elevation: 3,
},
  backgroundColor: '#FFFFFF',
  borderRadius: 12,
  padding: 16,
  flexDirection: 'row',
  alignItems: 'center',
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.1,
  shadowRadius: 4,
  elevation: 3,
},
cardLeft: {
  // Ocupa al menos el 60% de la tarjeta y crece si sobra espacio
  flexBasis: '60%',
  flexGrow: 1,
  paddingRight: 12,
},
dateText: {
  fontSize: 14,
  color: '#555555',
  marginBottom: 4,
},
greenDot: {
  color: '#4CAF50',
},
cardTitle: {
  fontSize: 16,
  fontWeight: '600',
  color: '#222222',
  marginBottom: 4,
},
cardDescription: {
  fontSize: 14,
  color: '#666666',
},

cardImage: {
  // Tamaño fijo 4:3 para que no se expanda
  width: 120,
  height: 90,
  borderRadius: 8,
  resizeMode: 'cover',
},

// Plus button
plusButton: {
  position: 'absolute',
  right: 16,
  bottom: -12,
  backgroundColor: '#3A81F7',
  borderRadius: 28,
  width: 56,
  height: 56,
  alignItems: 'center',
  justifyContent: 'center',
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.2,
  shadowRadius: 4,
  elevation: 4,
},

// Warning & action
warningText: {
  fontSize: 14,
  color: '#D32F2F',
  fontWeight: '500',
  marginBottom: 8,
},
amountText: {
  fontSize: 20,
  fontWeight: '700',
  color: '#222222',
  marginBottom: 12,
},
actionButton: {
  backgroundColor: '#3A81F7',
  paddingVertical: 10,
  borderRadius: 8,
  alignItems: 'center',
},
actionButtonText: {
  color: '#FFFFFF',
  fontSize: 16,
  fontWeight: '600',
},

// Footer
footer: {
  flexDirection: 'row',
  justifyContent: 'space-around',
  paddingVertical: 12,
  backgroundColor: '#FFFFFF',
  borderTopWidth: 1,
  borderTopColor: '#E0E0E0',
},


});

export default globalStyles;

