import { StyleSheet } from "react-native";

const visitantesStyles = StyleSheet.create({
  contenedor: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',         
    paddingTop: 20,               
    backgroundColor: '#fff',
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: '#d3d3d3',
    padding: 6,
    marginVertical: 5,
    borderRadius: 6,
    width: '90%',
  },
  sectionTitle: {
    fontWeight: "bold",
    color: '#000',
  },
  sectionContent: {
    paddingVertical: 10,
    gap: 10,
    width: '90%',
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 8,
    borderRadius: 5,
  },
  inputGray: {
    backgroundColor: '#d3d3d3',
    padding: 8,
    borderRadius: 5,
    color: '#000',
    fontSize: 16,
    width: '40%',
    textAlign: 'center',
    marginLeft: 10,
  },
  label: {
    marginTop: 10,
    color: '#000',
    fontSize: 16,
    flex: 1,
  },
  rowContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
  },
  radioRow: {
    flexDirection: "row",
    gap: 15,
    marginBottom: 10,
  },
  radio: {
    borderWidth: 1,
    borderColor: "#ccc",
    paddingVertical: 5,
    paddingHorizontal: 15,
    borderRadius: 5,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioSelected: {
    backgroundColor: '#007bff',
    borderColor: '#007bff',
  },
  radioText: {
    color: '#000',
    fontSize: 16,
  },
  radioTextSelected: {
    color: '#fff',
    fontWeight: "bold",
  },
  submitButton: {
    backgroundColor: "#ccc",
    padding: 8,
    borderRadius: 6,
    alignItems: "center",
    width: '50%',
    alignSelf: 'center',
  },
  guardarButton: {
    alignSelf: "flex-end",
    padding: 6,
    backgroundColor: "#ccc",
    borderRadius: 5,
    alignItems: "center",
  },
  autorizarButton: {
    marginTop: 5,
    backgroundColor: "#ccc",
    padding: 6,
    borderRadius: 5,
    alignItems: "center",
    width: '50%',
  },
  buttonPressed: {
    backgroundColor: "#007bff",
  },
  buttonText: {
    color: "#000",
    fontWeight: "bold",
  },
  buttonTextPressed: {
    color: "#fff",
    fontWeight: "bold",
  },
  noFrecuentes: {
    textAlign: "center",
    color: "#999",
    marginVertical: 10,
  },
  frecuenteItem: {
    backgroundColor: "#eee",
    padding: 8,
    borderRadius: 5,
    marginVertical: 3,
  },
  iconButton: {
    alignSelf: 'flex-end',
    marginTop: 10,
  },
  modal: {
    justifyContent: 'center',
    margin: 0,
  },
  popupContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    marginHorizontal: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButton: {
    position: 'absolute',
    top: 10,
    right: 10,
  },
  closeButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  checkIcon: {
    marginBottom: 10,
  },
  popupTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    textAlign: 'center',
    marginBottom: 10,
  },
  popupMessage: {
    fontSize: 14,
    color: '#000',
    textAlign: 'center',
  },
  bottomNav: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: '#007bff', // Color azul similar al de la imagen
    height: 60,
    borderTopWidth: 1,
    borderTopColor: '#ccc',
  },
});

export default visitantesStyles;