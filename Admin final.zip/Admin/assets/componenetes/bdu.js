import User from './models.js';
import UserV from './modelsvisit.js';

import cors from 'cors';
import express from 'express';
import mongoose from 'mongoose';

const app = express();

app.use(cors());
app.use(express.json());

// Conexión a MongoDB Atlas
mongoose.connect('mongodb+srv://abelj:PRUEBACLUSTER@c.bndaa32.mongodb.net/sintegra?retryWrites=true&w=majority&appName=c', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Registro
app.post('/register', async (req, res) => {
  const { nombre, correo, contraseña } = req.body;
  console.log(nombre, correo, contraseña)
  //const hashedPassword = await bcrypt.hash(contraseña, 10);

  try {
    const user = await User.create({
      nombre : nombre,
      correo : correo,
      contraseña: contraseña,
    });

    res.status(201).json({ message: 'Usuario creado', user });
  } catch (e) {
     console.log('Onooooo',e)
  }
});

// Registro-v
app.post('/registervist', async (req, res) => {
  const { nombre, cc } = req.body;
  try {
    const VisitUser = await UserV.create({
      nombre : nombre,
      cc: cc,
    });
    res.status(201).json({ message: 'Usuario creado', VisitUser });
  } catch (e) {
     console.log('Onooooo',e)
  }
});


// Login
app.post('/login', async (req, res) => {
  const { correo, contraseña } = req.body;

  const user = await User.findOne({ correo });
  if (!user) return res.status(404).json({ error: 'Usuario no encontrado' });

  if (user.contraseña !== contraseña) return res.status(401).json({ error: 'Contraseña incorrecta' });

  res.json({ message: 'Login exitoso', userId: user._id });
});

app.listen(8080, () => console.log('API corriendo en http://localhost:8080'));
