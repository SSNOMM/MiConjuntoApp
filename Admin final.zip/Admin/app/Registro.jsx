import { useRouter } from "expo-router";
import { useState } from "react";
import { Alert, Image, ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";
import globalStyles from "../assets/Styles/GlobalStyles";

function Registro() {
  const router = useRouter();
  const [aceptaNotificaciones, setAceptaNotificaciones] = useState(false);

  // Estados para los campos
  const [nombreDueno, setNombreDueno] = useState('');
  const [noTorre, setNoTorre] = useState('');
  const [noApto, setNoApto] = useState('');
  const [nombreCompleto, setNombreCompleto] = useState('');
  const [cc, setCc] = useState('');
  const [telefono, setTelefono] = useState('');
  const [correo, setCorreo] = useState('');
  const [contraseña, setContraseña] = useState('');
  const [confirmarContraseña, setConfirmarContraseña] = useState('');

  const toggleCheckbox = () => {
    setAceptaNotificaciones(!aceptaNotificaciones);
  };

  const handleRegistro = async () => {
    if (!correo || !contraseña || !nombreCompleto) {
      Alert.alert('Campos incompletos', 'Por favor completa los campos obligatorios');
      return;
    }

    if (contraseña !== confirmarContraseña) {
      Alert.alert('Error', 'Las contraseñas no coinciden');
      return;
    }

    try {
      const res = await fetch('http://localhost:8080/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nombre: nombreCompleto,
          correo: correo,
          contraseña: contraseña
        }),
      });
      const data = await res.json();

      if (res.ok) {
        Alert.alert('Éxito', 'Registro exitoso');
        router.push("Login");
      } else {
        Alert.alert('Error', data.error || 'Error al registrar');
      }
    } catch (error) {
      console.error('Error en registro:', error);
      Alert.alert('Error', 'No se pudo conectar con el servidor');
    }
  };

  return (
    <ScrollView contentContainerStyle={globalStyles.Globalcontainer}>
      <View style={globalStyles.container}>
        <Image
          source={require("../assets/images/icon.png")}
          style={globalStyles.profileImage}
        />
        <Text style={globalStyles.title}>Foto de Perfil</Text>

        <Text style={globalStyles.label}>Nombre Dueño/a Apartamento</Text>
        <TextInput style={globalStyles.input} value={nombreDueno} onChangeText={setNombreDueno} />

        <View style={globalStyles.inputsTorres}>
          <View style={globalStyles.row}>
            <View style={globalStyles.halfInputContainer}>
              <Text style={globalStyles.label}>No Torre</Text>
              <TextInput style={globalStyles.inputtorre} value={noTorre} onChangeText={setNoTorre} />
            </View>
            <View style={globalStyles.halfInputContainer}>
              <Text style={globalStyles.label}>No Apto</Text>
              <TextInput style={globalStyles.inputapto} value={noApto} onChangeText={setNoApto} />
            </View>
          </View>
        </View>

        <Text style={globalStyles.label}>Nombre Completo</Text>
        <TextInput style={globalStyles.input} value={nombreCompleto} onChangeText={setNombreCompleto} />

        <Text style={globalStyles.label}>C.C</Text>
        <TextInput style={globalStyles.input} value={cc} onChangeText={setCc} keyboardType="numeric" />

        <Text style={globalStyles.label}>Teléfono</Text>
        <TextInput style={globalStyles.input} value={telefono} onChangeText={setTelefono} keyboardType="phone-pad" />

        <Text style={globalStyles.label}>Correo Electrónico</Text>
        <TextInput style={globalStyles.input} value={correo} onChangeText={setCorreo} keyboardType="email-address" />

        <View style={globalStyles.checkboxContainer}>
          <TouchableOpacity onPress={toggleCheckbox} style={globalStyles.checkbox}>
            {aceptaNotificaciones && (
              <View style={globalStyles.checkboxChecked} />
            )}
          </TouchableOpacity>
          <Text style={globalStyles.checkboxLabel}>
            Confirmo que deseo recibir notificaciones por medio del correo electrónico
          </Text>
        </View>

        <Text style={globalStyles.label}>Contraseña</Text>
        <TextInput style={globalStyles.input} secureTextEntry value={contraseña} onChangeText={setContraseña} />

        <Text style={globalStyles.label}>Confirmar Contraseña</Text>
        <TextInput style={globalStyles.input} secureTextEntry value={confirmarContraseña} onChangeText={setConfirmarContraseña} />

        <View style={globalStyles.row}>
          <TouchableOpacity
            style={[globalStyles.button, globalStyles.buttonGrey]}
            onPress={() => router.push("Login")}
          >
            <Text style={globalStyles.buttonText}>Volver</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[globalStyles.button, globalStyles.buttonBlue]}
            onPress={handleRegistro}
          >
            <Text style={[globalStyles.buttonText, globalStyles.buttonTextWhite]}>
              Registrarse
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

export default Registro;
