// components/EmailConfirmationScreen.jsx
// components/EmailConfirmationScreen.jsx
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image } from 'react-native';
import { useRouter } from 'expo-router';
import globalStyles from '../assets/Styles/GlobalStyles';

const VerCorreo = () => {
  const [email, setEmail] = useState('');
  const router = useRouter();

  const handleSendEmail = () => {
    console.log(`Enviando correo a: ${email}`);
    router.push('/VerContrasena'); // Navega a la pantalla para cambiar contraseña
  };

  const handleGoBack = () => {
    router.replace('/Login'); // Navega a la pantalla de Login
  };

  return (
    <View style={globalStyles.container}>
      <Image source={require('../assets/images/LogoSin.png')} style={globalStyles.logo} />
      
      <Text style={globalStyles.instructionText}>
        Ingrese el correo registrado con la cuenta
      </Text>

      <TextInput
        style={globalStyles.input}
        placeholder="correo electrónico"
        placeholderTextColor="#999"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />

      <TouchableOpacity style={globalStyles.button} onPress={handleSendEmail}>
        <Text style={globalStyles.buttonText}>Enviar correo de Confirmación</Text>
      </TouchableOpacity>

      <TouchableOpacity style={globalStyles.button} onPress={handleGoBack}>
        <Text style={globalStyles.buttonText}>Volver</Text>
      </TouchableOpacity>
    </View>
  );
};

export default VerCorreo;

