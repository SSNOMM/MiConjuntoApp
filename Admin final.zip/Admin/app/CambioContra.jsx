import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text, Image } from 'react-native';
import { useRouter } from 'expo-router';
import globalStyles from '../assets/Styles/GlobalStyles';

const CambiarContrasena = () => {
  const [nueva, setNueva] = useState('');
  const [confirmar, setConfirmar] = useState('');
  const router = useRouter();

  const handleContinuar = () => {
    // Aquí puedes validar y enviar al backend
    console.log('Cambiar contraseña a:', nueva);
    router.push('/Login'); // O redirigir a inicio de sesión
  };

  return (
    <View style={globalStyles.container}>
      <Image
        source={require('../assets/images/LogoSin.png')}
        style={globalStyles.logo}
      />

      <TextInput
        style={globalStyles.input}
        placeholder="Contraseña Nueva"
        secureTextEntry
        value={nueva}
        onChangeText={setNueva}
      />
      <TextInput
        style={globalStyles.input}
        placeholder="Confirmar Contraseña"
        secureTextEntry
        value={confirmar}
        onChangeText={setConfirmar}
      />

      <TouchableOpacity style={globalStyles.button} onPress={handleContinuar}>
        <Text style={globalStyles.buttonText}>Continuar</Text>
      </TouchableOpacity>
    </View>
  );
};

export default CambiarContrasena;
