import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { Image, Text, TouchableOpacity, View } from "react-native";
import globalStyles from "../assets/Styles/GlobalStyles";

export default function Home() {
  const router = useRouter();


  
  return (

    
    <View style={globalStyles.homeContainer}>
      {/* Header */}
      <View style={globalStyles.header}>
        <Text style={globalStyles.headerText}>Mi Conjunto App</Text>
      </View>

      {/* Comunicados */}
      <View style={globalStyles.sectionContainer}>
        <Text style={globalStyles.sectionTitle}>Comunicados</Text>
        <View style={globalStyles.card}>
          <View style={globalStyles.cardLeft}>
            <Text style={globalStyles.dateText}>
              20/04/2025 <Text style={globalStyles.greenDot}>●</Text>
            </Text>
            <Text style={globalStyles.cardTitle}>Jornada de Reciclaje Comunitario</Text>
            <Text style={globalStyles.cardDescription}>
              Sábado 20 de abril a las 10:00 a.m. Torre 3
            </Text>
          </View>
          <Image
            source={require("../assets/images/edificio.jpg")}
            style={globalStyles.cardImage}
          />
        </View>
        <TouchableOpacity style={globalStyles.plusButton}>
          <Ionicons name="add" size={24} color="white" />
        </TouchableOpacity>
      </View>

      {/* Trámites */}
      <View style={globalStyles.sectionContainer}>
        <Text style={globalStyles.sectionTitle}>Trámites</Text>
        <View style={globalStyles.card}>
          <Text style={globalStyles.warningText}>¡22/04/2025! Último plazo pago administración</Text>
          <Text style={globalStyles.amountText}>$400.000</Text>
          <TouchableOpacity style={globalStyles.actionButton}>
            <Text style={globalStyles.actionButtonText}>Pagar Ahora</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity style={globalStyles.plusButton}>
          <Ionicons name="add" size={24} color="white" />
        </TouchableOpacity>
      </View>

      {/* Visitantes */}
      <View style={globalStyles.sectionContainer}>
  <Text style={globalStyles.sectionTitle}>Visitantes</Text>
  <View style={globalStyles.card}>
    <Text style={globalStyles.cardDescription}>¡Visitante anunciado en Portería!</Text>
    <TouchableOpacity
      style={globalStyles.actionButton}
      onPress={() => router.push("visitantes")}    // <— aquí
    >
      <Text style={globalStyles.actionButtonText}>Permitir Ingreso</Text>
    </TouchableOpacity>
  </View>
  <TouchableOpacity style={globalStyles.plusButton}>
    <Ionicons name="add" size={24} color="white" />
  </TouchableOpacity>
</View>

      {/* Footer */}
      <View style={globalStyles.footer}>
        <Ionicons name="person-outline" size={24} color="#888" />
        <Ionicons name="home" size={28} color="#3A81F7" />
        <Ionicons name="person-circle-outline" size={24} color="#888" />
      </View>
    </View>
  );
}
