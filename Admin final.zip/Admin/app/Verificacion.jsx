import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router'; // ✅ Importar router
import globalStyles from '../assets/Styles/GlobalStyles';

const Verificacion = () => {
  const router = useRouter(); // ✅ Inicializar router
  const correo = 'lavahemon@gmail.com';

  return (
    <View style={globalStyles.containerC}>
      <Image source={require("../assets/images/App.png")} style={globalStyles.logoC} />

      <Text style={globalStyles.textC}>
        Hemos enviado un correo de verificación a <Text style={globalStyles.email}>{correo}</Text>.
      </Text>

      <Text style={globalStyles.textC}>
        Por favor, revisa tu bandeja de entrada (y la carpeta de spam) y haz clic en el enlace para activar tu cuenta.
      </Text>

      <Text style={globalStyles.textC}>
        Una vez confirmes tu correo, podrás iniciar sesión y comenzar a usar Sintegra.
      </Text>

      <Text style={globalStyles.resendTextC}>
        ¿No recibió un correo? <Text style={globalStyles.resendLinkC}>Reenviar</Text>
      </Text>

      <View style={globalStyles.buttonContainerC}>
        <TouchableOpacity
          style={globalStyles.backButtonC}
          onPress={() => router.push('Registro')} // ✅ Ir a Registro
        >
          <Text style={globalStyles.backTextC}>Volver</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={globalStyles.continueButtonC}
          onPress={() => router.push('Login')} // ✅ Ir a Login
        >
          <Text style={globalStyles.continueTextC}>Continuar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Verificacion;
