import React from 'react';
import { View, Text, TouchableOpacity, Image } from 'react-native';
import { useRouter } from 'expo-router';
import globalStyles from '../assets/Styles/GlobalStyles';

const VerContrasena = () => {
  const router = useRouter();

  const handleContinue = () => {
    router.push('/CambioContra'); // 👉 Asegúrate de tener esta pantalla creada
  };

  const handleGoBack = () => {
    router.replace('/VerCorreo'); // 👉 Vuelve a la pantalla anterior
  };

  return (
    <View style={globalStyles.container}>
      <Image
        source={require('../assets/images/LogoSin.png')}
        style={globalStyles.logo}
      />

      <Text style={globalStyles.mainText}>
        Hemos enviado un correo de verificación a
      </Text>
      <Text style={globalStyles.emailText}>lavahemon@gmail.com</Text>

      <Text style={globalStyles.instructions}>
        Por favor, revisa tu bandeja de entrada (y la carpeta de spam) y haz clic en el enlace para activar tu cuenta.
      </Text>

      <Text style={globalStyles.instructions}>
        Una vez confirmes tu correo, podrás cambiar la contraseña.
      </Text>

      <Text style={globalStyles.resendText}>
        ¿No recibió un correo? <Text style={globalStyles.link}>Reenviar</Text>
      </Text>

      <View style={globalStyles.buttonContainer}>
        <TouchableOpacity style={globalStyles.backButton} onPress={handleGoBack}>
          <Text style={globalStyles.backButtonText}>Volver</Text>
        </TouchableOpacity>

        <TouchableOpacity style={globalStyles.continueButton} onPress={handleContinue}>
          <Text style={globalStyles.continueButtonText}>Continuar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default VerContrasena;

