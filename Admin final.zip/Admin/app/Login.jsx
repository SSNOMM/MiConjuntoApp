import { useRouter } from "expo-router";
import { useState } from "react";
import { Image, Text, TextInput, TouchableOpacity, View } from "react-native";
import globalStyles from "../assets/Styles/GlobalStyles";

export default function Login() {
  const router = useRouter();

  const [correo, setCorreo] = useState('');
  const [contraseña, setContraseña] = useState('');

  const handleLogin = async () => {
    if (!correo || !contraseña) {
      alert('Campos incompletos', 'Por favor completa los campos obligatorios');
      return;
    }

    try {
      const res = await fetch('http://localhost:8080/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          correo: correo,
          contraseña: contraseña
        }),
      });
      const data = await res.json();

      if (res.ok) {
        alert('Éxito', 'Login exitoso');
        router.push("Home");
      } else {
        alert('VaLENTINA TONTA', data.error || 'Error al loguear');
      }
    } catch (error) {
      console.error('Error en logueo:', error);
      alert('Error', 'No se pudo conectar con el servidor');
    }
  };
  
  return (
    <View style={globalStyles.globalContainerLogin}>
      <Image
        source={require("../assets/images/icon.png")}
        style={globalStyles.profileImage}
      />

      <Text style={globalStyles.text}>Usuario</Text>
      <TextInput
        placeholder=""
        value={correo} onChangeText={setCorreo}
        style={globalStyles.inputLogin}
        placeholderTextColor="#888"
      />

      <Text style={globalStyles.text}>Contraseña</Text>
      <TextInput
        placeholder=""
        value={contraseña} onChangeText={setContraseña}
        secureTextEntry={true}
        style={globalStyles.passwordInputLogin}
        placeholderTextColor="#888"
      />

      <TouchableOpacity onPress={() => router.push("VerCorreo")}>
        <Text style={globalStyles.forgotTextLogin}>¿Olvidó su contraseña?</Text>
      </TouchableOpacity>

      <TouchableOpacity
  style={globalStyles.buttonBlueLogin}
  onPress={() => handleLogin()}
>
  <Text style={[globalStyles.buttonTextLogin, globalStyles.buttonTextWhiteLogin]}>
    Iniciar Sesión
  </Text>
</TouchableOpacity>


      <Text style={globalStyles.registerTextLogin}>
        ¿No tienes Cuenta?{" "}
        <Text
          style={globalStyles.registerLinkLogin}
          onPress={() => router.push("Registro")}
        >
          Regístrate
        </Text>
      </Text>
    </View>
  );
}
