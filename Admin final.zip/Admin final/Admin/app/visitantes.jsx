import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
  Alert,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";
import visitantesStyles from "../assets/Styles/VisitantesStyles";

export default function Visitantes() {
  const router = useRouter();
  const [showRegistro, setShowRegistro] = useState(false);
  const [showFrecuente, setShowFrecuente] = useState(false);
  const [nombre, setNombre] = useState("");
  const [cc, setCC] = useState("");
  const [parqueadero, setParqueadero] = useState(null);
  const [horaLlegada, setHoraLlegada] = useState("");
  const [horaSalida, setHoraSalida] = useState("");
  const [placaVehiculo, setPlacaVehiculo] = useState("");
  const [frecuentes, setFrecuentes] = useState([]);
  const [nombreFrecuente, setNombreFrecuente] = useState("");
  const [ccFrecuente, setCCFrecuente] = useState("");
  const [isEnviarPressed, setIsEnviarPressed] = useState(false);
  const [isGuardarPressed, setIsGuardarPressed] = useState(false);
  const [autorizarPressedStates, setAutorizarPressedStates] = useState([]);

  const toggleRegistro = () => setShowRegistro(!showRegistro);
  const toggleFrecuente = () => setShowFrecuente(!showFrecuente);

  const registrarVisita = () => {
    if (nombre && cc) {
      Alert.alert("Visita registrada", "¡Visita para hoy autorizada!");
      setNombre("");
      setCC("");
      setParqueadero(null);
      setHoraLlegada("");
      setHoraSalida("");
      setPlacaVehiculo("");
    }
  };

  const registrarFrecuente = () => {
    if (nombreFrecuente && ccFrecuente) {
      setFrecuentes([
        ...frecuentes,
        { nombre: nombreFrecuente, cc: ccFrecuente },
      ]);
      setAutorizarPressedStates([...autorizarPressedStates, false]);
      setNombreFrecuente("");
      setCCFrecuente("");
    }
  };

  const handleAutorizarPressIn = (index) => {
    const s = [...autorizarPressedStates];
    s[index] = true;
    setAutorizarPressedStates(s);
  };
  const handleAutorizarPressOut = (index) => {
    const s = [...autorizarPressedStates];
    s[index] = false;
    setAutorizarPressedStates(s);
  };

  return (
    <View style={visitantesStyles.screenContainer}>
      <View style={visitantesStyles.phoneWrapper}>
        <View style={visitantesStyles.header}>
          <Text style={visitantesStyles.headerTitle}>Mi Conjunto</Text>
        </View>

        <ScrollView contentContainerStyle={{ paddingBottom: 100 }}>
          <View style={visitantesStyles.contenedor}>
            {/* Registrar Visita */}
            <TouchableOpacity
              style={visitantesStyles.sectionHeader}
              onPress={toggleRegistro}
            >
              <Text style={visitantesStyles.sectionTitle}>
                Registrar Visita para Hoy
              </Text>
              <Ionicons
                name={showRegistro ? "chevron-up" : "chevron-down"}
                size={20}
                color="#000"
              />
            </TouchableOpacity>

            {showRegistro && (
              <View style={visitantesStyles.sectionContent}>
                <TextInput
                  value={nombre}
                  onChangeText={setNombre}
                  style={visitantesStyles.input}
                  placeholder="Nombre Completo"
                />
                <TextInput
                  value={cc}
                  onChangeText={setCC}
                  style={visitantesStyles.input}
                  placeholder="C.C"
                />

                <Text style={visitantesStyles.label}>Uso parqueadero</Text>
                <View style={visitantesStyles.radioRow}>
                  <TouchableOpacity
                    onPress={() => setParqueadero(true)}
                    style={[
                      visitantesStyles.radio,
                      parqueadero === true &&
                        visitantesStyles.radioSelected,
                    ]}
                  >
                    <Text
                      style={[
                        visitantesStyles.radioText,
                        parqueadero === true &&
                          visitantesStyles.radioTextSelected,
                      ]}
                    >
                      Sí
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => setParqueadero(false)}
                    style={[
                      visitantesStyles.radio,
                      parqueadero === false &&
                        visitantesStyles.radioSelected,
                    ]}
                  >
                    <Text
                      style={[
                        visitantesStyles.radioText,
                        parqueadero === false &&
                          visitantesStyles.radioTextSelected,
                      ]}
                    >
                      No
                    </Text>
                  </TouchableOpacity>
                </View>

                {parqueadero && (
                  <>
                    <View style={visitantesStyles.rowContainer}>
                      <Text style={visitantesStyles.label}>
                        Hora de Llegada
                      </Text>
                      <TextInput
                        value={horaLlegada}
                        onChangeText={setHoraLlegada}
                        style={visitantesStyles.inputGray}
                      />
                    </View>
                    <View style={visitantesStyles.rowContainer}>
                      <Text style={visitantesStyles.label}>
                        Hora de Salida
                      </Text>
                      <TextInput
                        value={horaSalida}
                        onChangeText={setHoraSalida}
                        style={visitantesStyles.inputGray}
                      />
                    </View>
                    <View style={visitantesStyles.rowContainer}>
                      <Text style={visitantesStyles.label}>
                        Placa Vehículo
                      </Text>
                      <TextInput
                        value={placaVehiculo}
                        onChangeText={setPlacaVehiculo}
                        style={visitantesStyles.inputGray}
                      />
                    </View>
                  </>
                )}

                <TouchableOpacity
                  style={[
                    visitantesStyles.submitButton,
                    isEnviarPressed && visitantesStyles.buttonPressed,
                  ]}
                  onPressIn={() => setIsEnviarPressed(true)}
                  onPressOut={() => setIsEnviarPressed(false)}
                  onPress={registrarVisita}
                >
                  <Text
                    style={[
                      visitantesStyles.buttonText,
                      isEnviarPressed &&
                        visitantesStyles.buttonTextPressed,
                    ]}
                  >
                    Enviar
                  </Text>
                </TouchableOpacity>
              </View>
            )}

            {/* Visitantes Frecuentes */}
            <TouchableOpacity
              style={visitantesStyles.sectionHeader}
              onPress={toggleFrecuente}
            >
              <Text style={visitantesStyles.sectionTitle}>
                Visitante frecuente
              </Text>
              <Ionicons
                name={showFrecuente ? "chevron-up" : "chevron-down"}
                size={20}
                color="#000"
              />
            </TouchableOpacity>

            {showFrecuente && (
              <View style={visitantesStyles.sectionContent}>
                {frecuentes.length === 0 ? (
                  <Text style={visitantesStyles.noFrecuentes}>
                    Ningún Visitante Frecuente Registrado
                  </Text>
                ) : (
                  frecuentes.map((f, i) => (
                    <View style={visitantesStyles.frecuenteItem} key={i}>
                      <Text>{f.nombre}</Text>
                      <TouchableOpacity
                        style={[
                          visitantesStyles.autorizarButton,
                          autorizarPressedStates[i] &&
                            visitantesStyles.buttonPressed,
                        ]}
                        onPressIn={() => handleAutorizarPressIn(i)}
                        onPressOut={() => handleAutorizarPressOut(i)}
                        onPress={registrarVisita}
                      >
                        <Text
                          style={[
                            visitantesStyles.buttonText,
                            autorizarPressedStates[i] &&
                              visitantesStyles.buttonTextPressed,
                          ]}
                        >
                          Autorizar para hoy
                        </Text>
                      </TouchableOpacity>
                    </View>
                  ))
                )}

                <TextInput
                  style={visitantesStyles.input}
                  placeholder="Nombre Completo"
                  value={nombreFrecuente}
                  onChangeText={setNombreFrecuente}
                />
                <TextInput
                  style={visitantesStyles.input}
                  placeholder="C.C"
                  value={ccFrecuente}
                  onChangeText={setCCFrecuente}
                />

                <TouchableOpacity
                  style={[
                    visitantesStyles.guardarButton,
                    isGuardarPressed &&
                      visitantesStyles.buttonPressed,
                  ]}
                  onPressIn={() => setIsGuardarPressed(true)}
                  onPressOut={() => setIsGuardarPressed(false)}
                  onPress={registrarFrecuente}
                >
                  <Text
                    style={[
                      visitantesStyles.buttonText,
                      isGuardarPressed &&
                        visitantesStyles.buttonTextPressed,
                    ]}
                  >
                    Guardar
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </ScrollView>

        {/* NAVEGACIÓN INFERIOR */}
        <View style={visitantesStyles.bottomNav}>
          <TouchableOpacity
            style={visitantesStyles.navItem}
            onPress={() => router.push("/chat")}
          >
            <Ionicons name="chatbubble-outline" size={24} color="#007bff" />
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              visitantesStyles.navItem,
              visitantesStyles.navItemActive,
            ]}
            onPress={() => router.push("/home")}
          >
            <Ionicons name="home-outline" size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity
            style={visitantesStyles.navItem}
            onPress={() => router.push("/perfil")}
          >
            <Ionicons name="person-outline" size={24} color="#007bff" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

 