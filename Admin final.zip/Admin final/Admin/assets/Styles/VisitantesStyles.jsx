import { Dimensions, StyleSheet } from "react-native";
const { height: windowHeight } = Dimensions.get('window');

const visitantesStyles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: '#F2F2F2',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 20,
  },

  phoneWrapper: {
    width: 375,
    height: windowHeight * 0.9,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 5,
    paddingTop: 20,
    alignItems: 'center',
  },

  // ** Header curvo **
  // En VisitantesStyles.js, sustituye tu definición de `header` por esta:

header: {
  width: '100%',
  height: 60,                      // reducimos la altura total
  backgroundColor: '#007bff',
  borderBottomLeftRadius: 200,     // radio muy grande para arco suave
  borderBottomRightRadius: 200,    // igual al otro lado
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden',
  marginBottom: 10,
},
headerTitle: {
  color: '#fff',
  fontSize: 22,                    // un poco más grande para destacar
  fontWeight: 'bold',
},


  contenedor: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#fff',
    width: '100%',
    paddingHorizontal: 16,
  },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginVertical: 5,
    width: '100%',
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },

  sectionTitle: {
    fontWeight: 'bold',
    color: '#000',
    fontSize: 16,
  },

  sectionContent: {
    paddingVertical: 10,
    gap: 10,
    width: '90%',
    alignSelf: 'center',
  },

  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 8,
    borderRadius: 5,
    width: '90%',
    alignSelf: 'center',
    marginVertical: 6,
    color: '#000',
  },

  inputGray: {
    backgroundColor: '#d3d3d3',
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 8,
    borderRadius: 5,
    color: '#000',
    fontSize: 16,
    width: '40%',
    textAlign: 'center',
    marginLeft: 10,
  },

  label: {
    marginTop: 10,
    color: '#000',
    fontSize: 16,
    flex: 1,
  },

  rowContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
  },

  radioRow: {
    flexDirection: 'row',
    gap: 15,
    marginBottom: 10,
    width: '90%',
    alignSelf: 'center',
  },

  radio: {
    borderWidth: 1,
    borderColor: '#ccc',
    paddingVertical: 5,
    paddingHorizontal: 15,
    borderRadius: 5,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },

  radioSelected: {
    backgroundColor: '#007bff',
    borderColor: '#007bff',
  },

  radioText: {
    color: '#000',
    fontSize: 16,
  },

  radioTextSelected: {
    color: '#fff',
    fontWeight: 'bold',
  },

  submitButton: {
    backgroundColor: '#007bff',
    padding: 12,
    borderRadius: 6,
    alignItems: 'center',
    width: '50%',
    alignSelf: 'center',
    marginVertical: 10,
  },

  guardarButton: {
    alignSelf: 'flex-end',
    padding: 6,
    backgroundColor: '#007bff',
    borderRadius: 5,
    alignItems: 'center',
    marginRight: 16,
  },

  autorizarButton: {
    marginTop: 5,
    backgroundColor: '#007bff',
    padding: 6,
    borderRadius: 5,
    alignItems: 'center',
    width: '50%',
    alignSelf: 'center',
  },

  buttonPressed: {
    backgroundColor: '#0056b3',
  },

  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },

  buttonTextPressed: {
    color: '#fff',
    fontWeight: 'bold',
  },

  noFrecuentes: {
    textAlign: 'center',
    color: '#999',
    marginVertical: 10,
  },

  frecuenteItem: {
    backgroundColor: '#eee',
    padding: 8,
    borderRadius: 5,
    marginVertical: 3,
    width: '90%',
    alignSelf: 'center',
  },

  iconButton: {
    alignSelf: 'flex-end',
    marginTop: 10,
    marginRight: 16,
  },

bottomNav: {
  position: 'absolute',
  bottom: 0,
  left: 0,
  right: 0,

  height: 60,
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
  paddingHorizontal: 40,

  backgroundColor: '#fff',      // fondo blanco
  borderTopWidth: 1,            // línea azul fina arriba
  borderTopColor: '#007bff',
},

navItem: {
  alignItems: 'center',
  justifyContent: 'center',
  width: 50,                    // ancho fijo para tercios
  height: 50,
},

navItemActive: {
  backgroundColor: '#007bff',   // círculo azul
  borderRadius: 25,             // radio mitad del ancho/alto
  marginTop: -20,               // eleva el círculo sobre la línea
  shadowColor: '#000',          // opcional: sombra para dar relieve
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.2,
  shadowRadius: 4,
  elevation: 3,
},




  // ...tus estilos de modales siguen igual
});

export default visitantesStyles;
