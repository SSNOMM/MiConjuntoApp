const mongoose = require('mongoose');

const userVisitSchema = new mongoose.Schema({
  nombre: String,
  cc: String,
});

module.exports = mongoose.model('Visitantes', userVisitSchema);
