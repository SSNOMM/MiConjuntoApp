// assets/Styles/CamContra.js
import { StyleSheet } from 'react-native';

const CamContra = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
  },

  headerImage: {
        marginTop:0,
    width: 420,
    height: 190,
alignSelf:"center",
marginBottom:50,
  },

  input: {
    alignSelf:"center",
    width: '90%',
    backgroundColor: '#d9d9d9',
    paddingVertical: 12,
    paddingHorizontal: 15,
    borderRadius: 6,
    marginBottom: 20,
    fontSize: 14,
    color: '#000',
  },

  button: {
    backgroundColor: '#2d7dca',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 6,
    alignItems: 'center',
    width: '40%',
    marginTop: 40,
    marginLeft:210,
  },

  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 15,
  },
});

export default CamContra;
