import { StyleSheet, Dimensions } from "react-native";

const { width } = Dimensions.get("window");

const CorreoVreg = StyleSheet.create({
  containerC: {
    flex: 1,
    backgroundColor: "#fffff",
  },

  topBlueArea: {
    width: "100%",
    height: 180,
    backgroundColor: "#2E74B5",
    borderBottomLeftRadius: 120,
    borderBottomRightRadius: 120,
    justifyContent: "center",
    alignItems: "center",
  },

  logoC: {
    marginTop:0,
    width: 400,
    height: 190,
alignSelf:"center",
  },

  messageContainerC: {
    marginTop: 40,
    marginHorizontal: 30,
  },

  textC: {
    fontSize: 15,
    color: "#000",
    textAlign: "center",
    marginBottom: 15,
    lineHeight: 22,
    fontWeight: "400",
  },

  emailText: {
    fontWeight: "600",
    marginBottom: 30,
  },

  resendTextC: {
    textAlign: "center",
    fontSize: 13,
    color: "#000",
    marginBottom: 30,
  },

  resendLinkC: {
    color: "#2E74B5",
    textDecorationLine: "underline",
  },

  buttonContainerC: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 30,
  },

  backButtonC: {
    width:130,
    height: 40,
    borderColor: "#2E74B5",
    borderWidth: 1,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    marginTop:60,
  },

  backTextC: {
    color: "#2E74B5",
    fontSize: 16,
  },

  continueButtonC: {
    width: 120,
    height: 40,
    backgroundColor: "#2E74B5",
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
      marginTop:60,
  },

  continueTextC: {
    color: "#FFF",
    fontSize: 16,
  },
});

export default CorreoVreg;
