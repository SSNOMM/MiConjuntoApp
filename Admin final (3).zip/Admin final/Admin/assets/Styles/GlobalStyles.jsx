import { Platform, StyleSheet } from 'react-native';

const globalStyles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: '#fff',
    width: '100%',
    maxWidth: 390,
    alignSelf: 'center',
    paddingHorizontal: 20,
  },

  Globalcontainer: {
    flex: 1,
    alignSelf: "center",
    width: "100%",
  },

  container: {
    padding: 20,
    backgroundColor: "#fff",
    maxWidth: 390,
    width: '100%',
    alignSelf: 'center',
  },

  title: {
    textAlign: "center",
    marginBottom: 10,
    fontSize: 18,
    fontWeight: "bold",
  },

  label: {
    marginTop: 10,
    marginBottom: 5,
    fontSize: 14,
    color: "#333",
  },

  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 8,
    backgroundColor: "#D9D9D9",
    marginBottom: 10,
    borderRadius: 4,
    fontSize: 14,
    width: '100%',
    maxWidth: 340,
    height: 40,
    alignSelf: 'center',
  },

  inputtorre: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 8,
    backgroundColor: "#D9D9D9",
    marginBottom: 10,
    borderRadius: 4,
    fontSize: 14,
    width: 80,
    height: 32,
  },

  inputapto: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 8,
    backgroundColor: "#D9D9D9",
    marginBottom: 10,
    borderRadius: 4,
    fontSize: 14,
    width: 80,
    height: 32,
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
  },

  inputsTorres: {
    display: "flex",
  },

  halfInputContainer: {
    display: "flex",
    flex: 1,
    marginHorizontal: 5,
    flexDirection: "row",
    gap: 10,
  },

  checkboxContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },

  checkbox: {
    width: 20,
    height: 20,
    borderWidth: 1,
    borderColor: "#000",
    marginRight: 5,
    justifyContent: "center",
    alignItems: "center",
  },

  checkboxChecked: {
    width: 12,
    height: 12,
    backgroundColor: "#007bff",
  },

  checkboxLabel: {
    flex: 1,
    fontSize: 12,
    color: "#555",
  },

  button: {
    flex: 1,
    padding: 10,
    marginHorizontal: 5,
    borderRadius: 4,
    alignItems: "center",
    justifyContent: "center",
  },

  buttonGrey: {
    backgroundColor: "#ccc",
    width: '100%',
    maxWidth: 148,
    height: 32,
    alignSelf: 'center',
  },

  buttonBlue: {
    backgroundColor: "#007bff",
    marginBottom: 10,
    width: '100%',
    maxWidth: 148,
    height: 32,
    alignSelf: 'center',
  },

  buttonText: {
    fontSize: 14,
  },

  buttonTextWhite: {
    color: "#fff",
  },

  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: "#d9d9d9",
    marginBottom: 30,
    alignSelf: "center",
  },

  globalContainerLogin: {
    flex: 1,
    width: "100%",
    maxWidth: 390,
    padding: 20,
    backgroundColor: "#fff",
    justifyContent: 'space-evenly',
    alignSelf: 'center',
  },

  text: {
    fontSize: 14,
    color: "#333",
    marginLeft: 20,
  },

  inputLogin: {
    backgroundColor: "#d9d9d9",
    width: '100%',
    maxWidth: 340,
    height: 40,
    padding: 10,
    borderRadius: 5,
    marginBottom: 15,
    alignSelf: "center",
  },

  passwordInputLogin: {
    backgroundColor: "#d9d9d9",
    width: '100%',
    maxWidth: 340,
    height: 40,
    padding: 10,
    borderRadius: 5,
    marginBottom: 15,
    alignSelf: "center",
  },

  eyeIconLogin: {
    width: 24,
    height: 24,
    tintColor: "#888",
  },

  forgotTextLogin: {
    alignSelf: "flex-end",
    color: "#3578e5",
    marginBottom: 25,
    marginRight: 20,
  },

  buttonBlueLogin: {
    backgroundColor: "#3578e5",
    width: '100%',
    maxWidth: 340,
    height: 40,
    padding: 12,
    borderRadius: 5,
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 40,
  },

  buttonTextLogin: {
    fontSize: 16,
  },

  buttonTextWhiteLogin: {
    color: "#fff",
  },

  registerTextLogin: {
    fontSize: 14,
    color: "#333",
    alignSelf: "center",
  },

  registerLinkLogin: {
    color: "#3578e5",
  },

  containerC: {
    flex: 1,
    padding: 30,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },

  logoC: {
    width: 100,
    height: 100,
    marginBottom: 30,
    resizeMode: 'contain',
  },

  textC: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 15,
    color: '#333',
  },

  emailC: {
    fontWeight: 'bold',
  },

  resendTextC: {
    marginTop: 10,
    fontSize: 14,
    color: '#333',
  },

  resendLinkC: {
    color: '#1E90FF',
  },

  buttonContainerC: {
    flexDirection: 'row',
    marginTop: 40,
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 20,
  },

  backButtonC: {
    flex: 1,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#1E90FF',
    borderRadius: 8,
    marginRight: 10,
    alignItems: 'center',
  },

  backTextC: {
    color: '#1E90FF',
    fontWeight: 'bold',
  },

  continueButtonC: {
    flex: 1,
    paddingVertical: 12,
    backgroundColor: '#1E90FF',
    borderRadius: 8,
    marginLeft: 10,
    alignItems: 'center',
  },

  continueTextC: {
    color: '#fff',
    fontWeight: 'bold',
  },

  imagencarga: {
    alignSelf: "center",
    marginTop: "60%",
  },

  homeContainer: {
    flex: 1,
    backgroundColor: '#F2F2F2',
    width: '100%',
    maxWidth: 390,
    alignSelf: 'center',
    paddingBottom: 20,
  },

  header: {
    backgroundColor: '#3A81F7',
    paddingVertical: 12,
    alignItems: 'center',
    justifyContent: 'center',
    ...Platform.select({
      ios: { paddingTop: 40 },
      android: { paddingTop: 20 },
    }),
  },

  headerText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '600',
  },

  sectionContainer: {
    marginHorizontal: 16,
    marginTop: 24,
  },

  sectionTitle: {
    fontSize: 18,
    fontWeight: '500',
    color: '#333333',
    marginBottom: 8,
  },

  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    maxWidth: 360,
    alignSelf: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },

  cardLeft: {
    flexBasis: '60%',
    flexGrow: 1,
    paddingRight: 12,
  },

  dateText: {
    fontSize: 14,
    color: '#555555',
    marginBottom: 4,
  },

  greenDot: {
    color: '#4CAF50',
  },

  cardTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#222222',
    marginBottom: 4,
  },

  cardDescription: {
    fontSize: 14,
    color: '#666666',
  },

  cardImage: {
    width: 120,
    height: 90,
    borderRadius: 8,
    resizeMode: 'cover',
  },

  plusButton: {
    position: 'absolute',
    right: 16,
    bottom: -12,
    backgroundColor: '#3A81F7',
    borderRadius: 28,
    width: 56,
    height: 56,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },

  warningText: {
    fontSize: 14,
    color: '#D32F2F',
    fontWeight: '500',
    marginBottom: 8,
  },

  amountText: {
    fontSize: 20,
    fontWeight: '700',
    color: '#222222',
    marginBottom: 12,
  },

  actionButton: {
    backgroundColor: '#3A81F7',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },

  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },

  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
});

export default globalStyles;

