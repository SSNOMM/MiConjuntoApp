import { StyleSheet } from "react-native";

export default StyleSheet.create({
 header: {
  backgroundColor: "#2d7dca",
  paddingTop: 60,
  paddingHorizontal: 20,
  paddingBottom: 100,
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: "center",
  zIndex: 0,
  position: 'relative', // o 'absolute' si usas scroll}
  height:0,

},
  appName: {
    fontSize: 26,
    fontWeight: "bold",
    color: "white",
  },
  welcomeText: {

    fontSize: 18,
    color: "white",
    marginTop: 5,
    marginRight:120,
  },
  logo: {
    width: 100,
    height: 100,

  },
  seccion: {
    alignSelf:"center",
  backgroundColor: "white",
  borderTopLeftRadius: 30,
  borderTopRightRadius: 30,
  paddingTop: 20,
  paddingHorizontal: 20,
  marginTop: 0, // Ajusta este valor según el diseño
  flexGrow: 1,
  zIndex: 10,
  position: 'abosolute',
  width:"99%",
},
  titulo: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 10,
  },
  tarjeta: {
    backgroundColor: "#f9f9f9",
    borderRadius: 15,
    padding: 15,
    marginBottom: 25,
    shadowColor: "#606060",
    shadowOffset: { width: 5, height: 2 },
    shadowOpacity: 2,
    shadowRadius: 6,
    elevation: 4,
    position: "relative",
  },
  fecha: {
    fontSize: 14,
    color: "#555",
    marginBottom: 5,
 
  },
  subtitulo: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#222",
    marginBottom: 5,

  },
  descripcion: {
    fontSize: 14,
    color: "#444",
    marginBottom: 10,
    alignSelf:"center",
  },
  valor: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#2d7dca",
    marginBottom: 10,
        alignSelf:"center",
  },
  alerta: {
    fontSize: 14,
    color: "#c92a2a",
    fontWeight: "bold",
    marginBottom: 5,
        alignSelf:"center",
  },
  botonAccion: {
    backgroundColor: "#2d7dca",
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 10,
    alignSelf:"center",
    marginTop: 5,
  },
  textoBoton: {
    color: "white",
    fontSize: 14,
    fontWeight: "600",
  },
  botonMas: {
    marginLeft:300,
    top: 10,
    right: 10,
    backgroundColor: "#2d7dca",
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  menuInferior: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    backgroundColor: "white",
    paddingVertical: 10,
    borderTopColor: "#2d7dca",
    borderTopWidth: 1,
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
  },
  iconoMenu: {
    width: 30,
    height: 30,

  },
});
