// assets/Styles/VerCorr.js
import { StyleSheet } from 'react-native';

const VerCorr = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    alignItems: 'center',
  },

  headerImage: {
    marginTop:0,
    width: 450,
    height: 190,
    alignSelf:"center",
  },

  titleText: {
    fontSize: 16,
    color: '#000',
    textAlign: 'center',
    marginTop:40,
    marginBottom: 40,
    fontWeight: '500',
  },

  descriptionText: {
    fontSize: 14,
    color: '#000',
    textAlign: 'center',
    marginBottom: 10,
  },

  resendText: {
    fontSize: 13,
    color: '#000',
    marginTop: 15,
    marginBottom: 20,
  },

  link: {
    color: '#2E74B5',
    fontWeight: '600',
  },

  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },

  backButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#2E74B5',
    borderRadius: 6,
    paddingVertical: 10,
    marginRight: 10,
    alignItems: 'center',
  },

  backButtonText: {
    color: '#2E74B5',
    fontWeight: '600',
  },

  continueButton: {
    flex: 1,
    backgroundColor: '#2E74B5',
    borderRadius: 6,
    paddingVertical: 10,
    marginLeft: 10,
    alignItems: 'center',
  },

  continueButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
});

export default VerCorr;
