import { StyleSheet, Dimensions } from "react-native";
const { width } = Dimensions.get("window");

const MantenimientoS = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingTop: 80,
  },
  icono: {
    width: 400,
    height: 400,
    marginBottom: 20,
  },
  mensajeContainer: {
    paddingHorizontal: 30,
    alignItems: "center",
    marginTop: 20,
  },
  titulo: {
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 10,
  },
  descripcion: {
    fontSize: 14,
    textAlign: "center",
    marginBottom: 10,
  },
  gracias: {
    fontSize: 14,
    textAlign: "center",
    fontWeight: "600",
  },
  menuInferior: {
    position: "absolute",
    bottom: 0,
    flexDirection: "row",
    justifyContent: "space-around",
    width: "100%",
    height: 60,
    backgroundColor: "#fff",
    borderTopWidth: 2,
    borderColor: "#007bff",
    alignItems: "center",
    paddingHorizontal: 20,
  },
  iconoMenu: {
    width: 26,
    height: 26,

  },
});

export default MantenimientoS;
