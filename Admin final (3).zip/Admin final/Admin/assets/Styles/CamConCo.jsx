// assets/Styles/CamConCo.js
import { StyleSheet } from 'react-native';

const CamConCo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
  },

  headerImage: {
        marginTop:0,
    width: 400,
    height: 190,
alignSelf:"center",
  },

  instructionText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
    marginTop:40,
    marginBottom: 40,
    marginLeft:0,
  },

  input: {
    width: '100%',
    height: 32,
    backgroundColor: '#D3D3D3',
    borderRadius: 6,
    paddingHorizontal: 10,
    marginBottom: 30,
    color: '#333',
  },

  buttonSend: {
    width: '70%',
    height: 38,
    backgroundColor: '#2D7DCA',
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
    marginLeft:100,
  },
buttonBack: {
    width: '30%',
    height: 38,
    backgroundColor: '#fffff',
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
    borderColor:"#2d7dca",
    borderWidth:1,
  },
  buttonTextB: {
    color: '#000',
    fontWeight: '600',
  },
    buttonText: {
    color: '#FFF',
    fontWeight: '600',
  },
});

export default CamConCo;
