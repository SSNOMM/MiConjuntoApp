import { StyleSheet } from "react-native";

const RegistroStyles = StyleSheet.create({
  topEllipse: {
    position: "absolute",
    top: -110,
    left: 0,
    right: 0,
    width: "105%",
    height: 270,
    borderBottomLeftRadius: 150,
    borderBottomRightRadius: 160,
    backgroundColor: "#2D7DCA",
    zIndex: 1,
    alignSelf: "center",
  },

  Globalcontainer: {
    flexGrow: 1,
    backgroundColor: "#fff",
    justifyContent: "center",
  },

  container: {
    flex: 1,
    paddingHorizontal: 30,
    paddingVertical: 20,
    alignItems: "center",
    backgroundColor: "#fff",

  },

  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: "#e0e0e0",
    marginTop: 50,
    marginBottom: 10,
    zIndex: 2,
    alignSelf: "center",
  },

  title: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#333",
  },

  label: {
    alignSelf: "flex-start",
    marginTop: 10,
    marginBottom: 5,
    fontSize: 14,
    color: "#444",
  },

  input: {
    width: "100%",
    height: 32,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    backgroundColor: "#d9d9d9",
    marginBottom: 10,
  },

  inputtorre: {
    height: 40,
    width: 60,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    backgroundColor: "#d9d9d9",
    marginRight: 5,
  },

  inputapto: {
    height: 40,
    width: 60,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    backgroundColor: "#d9d9d9",
    marginLeft: 5,
  },

  inputsTorres: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginTop: 10,
  },

  inputGroup: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },

  labelSmall: {
    fontSize: 14,
    color: "#444",
    marginRight: 8,
    width: 60,
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    marginTop: 10,
  },

  halfInputContainer: {
    flex: 1,
  },

  checkboxContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 10,
    flexWrap: "wrap",
  },

  checkbox: {
    width: 20,
    height: 20,
    borderWidth: 1,
    borderColor: "#555",
    marginRight: 10,
    alignItems: "center",
    justifyContent: "center",
  },

  checkboxChecked: {
    width: 14,
    height: 14,
    backgroundColor: "#007bff",
  },

  checkboxLabel: {
    flex: 1,
    fontSize: 13,
    color: "#333",
  },

  button: {
    flex: 1,
    height: 45,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 5,
    marginHorizontal: 5,
    marginTop: 20,
  },

  buttonBlue: {
    backgroundColor: "#007bff",
  },

  buttonGrey: {
    backgroundColor: "#f2f2f2",
    borderWidth: 1,
    borderColor: "#ccc",
  },

  buttonText: {
    fontSize: 15,
    fontWeight: "bold",
  },

  buttonTextWhite: {
    color: "#fff",
    borderColor:"#2D7DCA",
  },
});

export default RegistroStyles;
