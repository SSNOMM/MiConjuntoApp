import { StyleSheet } from "react-native";

const loginStyles = StyleSheet.create({
  container: {
    height:"100%",
    padding: 20,
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 30,
    backgroundColor: "#ffffff",
  },

  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 40,
    backgroundColor: "#ddd",
    alignSelf:"center",
    marginTop:50,
  },

  text: {
    alignSelf: "flex-start",
    marginBottom: 5,
    fontSize: 16,
    color: "#333",
    fontWeight: "500",
    marginLeft:30,
  },

  inputLogin: {
    width: "85%",
    height: 32,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 20,
    paddingHorizontal: 10,
    backgroundColor: "#f2f2f2",
    alignSelf:"center",
  },

  passwordInputLogin: {
    width: "85%",
    height: 32,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 10,
    paddingHorizontal: 10,
    backgroundColor: "#f2f2f2",
    alignSelf:"center",
  },

  forgotTextLogin: {
    marginLeft:220,
    marginTop:15,
    marginBottom: 40,
    color: "#4285F4",
    fontSize: 13,
  },

  buttonBlueLogin: {
    width: "85%",
    height: 45,
    backgroundColor: "#4285F4",
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 80,
    alignSelf:"center",
  },

  buttonTextLogin: {
    fontSize: 16,
    fontWeight: "600",
  },

  buttonTextWhiteLogin: {
    color: "#fff",
  },

  registerTextLogin: {
    fontSize: 14,
    color: "#333",
    alignSelf:"center",
    marginTop:200,
  },

  registerLinkLogin: {
    color: "#4285F4",
    fontWeight: "500",
  },
});

export default loginStyles;
