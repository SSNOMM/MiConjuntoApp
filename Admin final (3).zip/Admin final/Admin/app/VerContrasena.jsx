// components/VerContrasena.jsx
import React from 'react';
import { View, Text, TouchableOpacity, Image } from 'react-native';
import { useRouter } from 'expo-router';
import VerCorr from '../assets/Styles/VerCorr';

const VerContrasena = () => {
  const router = useRouter();

  const handleContinue = () => {
    router.push('/CambioContra');
  };

  const handleGoBack = () => {
    router.replace('/VerCorreo');
  };

  return (
    <View style={VerCorr.container}>
      <Image
        source={require('../assets/images/Encabezado.png')} // Imagen del encabezado
        style={VerCorr.headerImage}
      />

      <Text style={VerCorr.titleText}>
        Hemos enviado un mensaje de verificación a tu correo
      </Text>

      <Text style={VerCorr.descriptionText}>
        Por favor, revisa tu bandeja de entrada (y la carpeta de spam) y haz clic en el enlace para activar la acción.
      </Text>

      <Text style={VerCorr.descriptionText}>
        Una vez confirmes tu correo, podrás cambiar la contraseña.
      </Text>

      <Text style={VerCorr.resendText}>
        ¿No recibió un correo? <Text style={VerCorr.link}>Reenviar</Text>
      </Text>

      <View style={VerCorr.buttonContainer}>
        <TouchableOpacity style={VerCorr.backButton} onPress={handleGoBack}>
          <Text style={VerCorr.backButtonText}>Volver</Text>
        </TouchableOpacity>

        <TouchableOpacity style={VerCorr.continueButton} onPress={handleContinue}>
          <Text style={VerCorr.continueButtonText}>Continuar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default VerContrasena;
