import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
Alert,
ScrollView,
Text,
TextInput,
TouchableOpacity,
View,
Image,
} from "react-native";
import Modal from "react-native-modal";
import visitantesStyles from "../assets/Styles/VisitantesStyles";

export default function Visitantes() {
const router = useRouter();
const [showRegistro, setShowRegistro] = useState(false);
const [showFrecuente, setShowFrecuente] = useState(false);
const [nombre, setNombre] = useState("");
const [cc, setCC] = useState("");
const [parqueadero, setParqueadero] = useState(null);
const [horaLlegada, setHoraLlegada] = useState("");
const [horaSalida, setHoraSalida] = useState("");
const [placaVehiculo, setPlacaVehiculo] = useState("");
const [frecuentes, setFrecuentes] = useState([]);
const [nombreFrecuente, setNombreFrecuente] = useState("");
const [ccFrecuente, setCCFrecuente] = useState("");
const [isVisitPopupVisible, setIsVisitPopupVisible] = useState(false);
const [isFrecuentePopupVisible, setIsFrecuentePopupVisible] = useState(false);
const [isAutorizarPopupVisible, setIsAutorizarPopupVisible] = useState(false);
const [isEnviarPressed, setIsEnviarPressed] = useState(false);
const [isGuardarPressed, setIsGuardarPressed] = useState(false);
const [autorizarPressedStates, setAutorizarPressedStates] = useState([]);

const toggleRegistro = () => setShowRegistro(!showRegistro);
const toggleFrecuente = () => setShowFrecuente(!showFrecuente);

const registrarVisita = () => {
if (nombre && cc) {
setIsVisitPopupVisible(true);
setNombre("");
setCC("");
setParqueadero(null);
setHoraLlegada("");
setHoraSalida("");
setPlacaVehiculo("");
}
};

const registrarFrecuente = () => {
if (nombreFrecuente && ccFrecuente) {
setFrecuentes([...frecuentes, { nombre: nombreFrecuente, cc: ccFrecuente }]);
setAutorizarPressedStates([...autorizarPressedStates, false]);
setIsFrecuentePopupVisible(true);
setNombreFrecuente("");
setCCFrecuente("");
}
};

const autorizarVisita = (index) => {
if (frecuentes.length > 0 && index >= 0 && index < frecuentes.length) {
setIsAutorizarPopupVisible(true);
}
};

const handleAutorizarPressIn = (index) => {
const newStates = [...autorizarPressedStates];
newStates[index] = true;
setAutorizarPressedStates(newStates);
};

const handleAutorizarPressOut = (index) => {
const newStates = [...autorizarPressedStates];
newStates[index] = false;
setAutorizarPressedStates(newStates);
};

const closeVisitPopup = () => setIsVisitPopupVisible(false);
const closeFrecuentePopup = () => setIsFrecuentePopupVisible(false);
const closeAutorizarPopup = () => setIsAutorizarPopupVisible(false);

const handleRegistro = async () => {
if (!nombre || !cc) {
Alert.alert('Campos incompletos', 'Por favor completa los campos obligatorios');
return;
}

try {
  const res = await fetch('http://localhost:8080/registervist', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nombre, cc }),
  });
  const data = await res.json();
  if (res.ok) {
    Alert.alert('Éxito', 'Registro exitoso');
  } else {
    Alert.alert('Error', data.error || 'Error al registrar');
  }
} catch (error) {
  console.error('Error en registro:', error);
  Alert.alert('Error', 'No se pudo conectar con el servidor');
}
};

return (
<View style={{ flex: 1 }}>
<ScrollView contentContainerStyle={{ flexGrow: 1 }}>
{/* Encabezado con imagen */}
<Image
source={require("../assets/images/EncabezadoCon.png")}
style={visitantesStyles.headerImage}
/>

    <View style={visitantesStyles.contenedor}>
      {/* Registrar Visita */}
      <TouchableOpacity style={visitantesStyles.sectionHeader} onPress={toggleRegistro}>
        <Text style={visitantesStyles.sectionTitle}>Registrar Visita para Hoy</Text>
        <Ionicons name={showRegistro ? "chevron-up" : "chevron-down"} size={20} color="#000" />
      </TouchableOpacity>

      {showRegistro && (
        <View style={visitantesStyles.sectionContent}>
          <TextInput
            value={nombre}
            onChangeText={setNombre}
            style={visitantesStyles.input}
            placeholder="Nombre Completo"
          />
          <TextInput
            style={visitantesStyles.input}
            placeholder="C.C"
            value={cc}
            onChangeText={setCC}
          />
          <Text style={visitantesStyles.label}>Uso parqueadero</Text>
          <View style={visitantesStyles.radioRow}>
            <TouchableOpacity
              onPress={() => setParqueadero(true)}
              style={[
                visitantesStyles.radio,
                parqueadero === true && visitantesStyles.radioSelected,
              ]}
            >
              <Text style={[
                visitantesStyles.radioText,
                parqueadero === true && visitantesStyles.radioTextSelected,
              ]}>Sí</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setParqueadero(false)}
              style={[
                visitantesStyles.radio,
                parqueadero === false && visitantesStyles.radioSelected,
              ]}
            >
              <Text style={[
                visitantesStyles.radioText,
                parqueadero === false && visitantesStyles.radioTextSelected,
              ]}>No</Text>
            </TouchableOpacity>
          </View>

          {parqueadero === true && (
            <>
              <View style={visitantesStyles.rowContainer}>
                <Text style={visitantesStyles.label}>Hora de Llegada</Text>
                <TextInput
                  style={visitantesStyles.inputGray}
                  value={horaLlegada}
                  onChangeText={setHoraLlegada}
                />
              </View>
              <View style={visitantesStyles.rowContainer}>
                <Text style={visitantesStyles.label}>Hora de Salida</Text>
                <TextInput
                  style={visitantesStyles.inputGray}
                  value={horaSalida}
                  onChangeText={setHoraSalida}
                />
              </View>
              <View style={visitantesStyles.rowContainer}>
                <Text style={visitantesStyles.label}>Placa Vehículo</Text>
                <TextInput
                  style={visitantesStyles.inputGray}
                  value={placaVehiculo}
                  onChangeText={setPlacaVehiculo}
                />
              </View>
            </>
          )}

          <TouchableOpacity
            style={[
              visitantesStyles.submitButton,
              isEnviarPressed && visitantesStyles.buttonPressed,
            ]}
            onPressIn={() => setIsEnviarPressed(true)}
            onPressOut={() => setIsEnviarPressed(false)}
            onPress={() => {
              handleRegistro();
              registrarVisita();
            }}
          >
            <Text
              style={[
                visitantesStyles.buttonText,
                isEnviarPressed && visitantesStyles.buttonTextPressed,
              ]}
            >
              Enviar
            </Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Visitante Frecuente */}
      <TouchableOpacity style={visitantesStyles.sectionHeader} onPress={toggleFrecuente}>
        <Text style={visitantesStyles.sectionTitle}>Visitante frecuente</Text>
        <Ionicons name={showFrecuente ? "chevron-up" : "chevron-down"} size={20} color="#000" />
      </TouchableOpacity>

      {showFrecuente && (
        <View style={visitantesStyles.sectionContent}>
          {frecuentes.length === 0 ? (
            <Text style={visitantesStyles.noFrecuentes}>Ningún Visitante Frecuente Registrado</Text>
          ) : (
            frecuentes.map((f, index) => (
              <View key={index} style={visitantesStyles.frecuenteItem}>
                <Text>{f.nombre}</Text>
                <TouchableOpacity
                  style={[
                    visitantesStyles.autorizarButton,
                    autorizarPressedStates[index] && visitantesStyles.buttonPressed,
                  ]}
                  onPressIn={() => handleAutorizarPressIn(index)}
                  onPressOut={() => handleAutorizarPressOut(index)}
                  onPress={() => autorizarVisita(index)}
                >
                  <Text
                    style={[
                      visitantesStyles.buttonText,
                      autorizarPressedStates[index] && visitantesStyles.buttonTextPressed,
                    ]}
                  >
                    Autorizar para hoy
                  </Text>
                </TouchableOpacity>
              </View>
            ))
          )}

          <TextInput
            style={visitantesStyles.input}
            placeholder="Nombre Completo"
            value={nombreFrecuente}
            onChangeText={setNombreFrecuente}
          />
          <TextInput
            style={visitantesStyles.input}
            placeholder="C.C"
            value={ccFrecuente}
            onChangeText={setCCFrecuente}
          />

          <TouchableOpacity
            style={[
              visitantesStyles.guardarButton,
              isGuardarPressed && visitantesStyles.buttonPressed,
            ]}
            onPressIn={() => setIsGuardarPressed(true)}
            onPressOut={() => setIsGuardarPressed(false)}
            onPress={registrarFrecuente}
          >
            <Text
              style={[
                visitantesStyles.buttonText,
                isGuardarPressed && visitantesStyles.buttonTextPressed,
              ]}
            >
              Guardar
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={visitantesStyles.iconButton} onPress={registrarVisita}>
            <Ionicons name="add-circle" size={32} color="#007bff" />
          </TouchableOpacity>
        </View>
      )}
    </View>
  </ScrollView>

  {/* Footer */}
 <View style={visitantesStyles.menuInferior}>
        
         <TouchableOpacity onPress={() => router.push("/tramites")}>
           <Image
             source={require("../assets/images/Chat.png")}
             style={visitantesStyles.iconoMenu}
           />
         </TouchableOpacity> 
         <TouchableOpacity onPress={() => router.push("Home")}>
           <Image
             source={require("../assets/images/Home.png")}
             style={visitantesStyles.iconoMenu}
           />
         </TouchableOpacity>
         <TouchableOpacity onPress={() => router.push("/perfil")}>
           <Image
             source={require("../assets/images/Porfile.png")}
             style={visitantesStyles.iconoMenu}
           />
         </TouchableOpacity>
       </View>

  {/* Modals */}
  <Modal isVisible={isVisitPopupVisible} onBackdropPress={closeVisitPopup} style={visitantesStyles.modal}>
    <View style={visitantesStyles.popupContainer}>
      <TouchableOpacity style={visitantesStyles.closeButton} onPress={closeVisitPopup}>
        <Text style={visitantesStyles.closeButtonText}>X</Text>
      </TouchableOpacity>
      <Ionicons name="checkmark-circle" size={30} color="#28a745" style={visitantesStyles.checkIcon} />
      <Text style={visitantesStyles.popupTitle}>¡Visita registrada con éxito!</Text>
      <Text style={visitantesStyles.popupMessage}>
        Tu visitante ha sido registrado correctamente. Recuerda: Debe presentar cédula en portería.
      </Text>
    </View>
  </Modal>

  <Modal isVisible={isFrecuentePopupVisible} onBackdropPress={closeFrecuentePopup} style={visitantesStyles.modal}>
    <View style={visitantesStyles.popupContainer}>
      <TouchableOpacity style={visitantesStyles.closeButton} onPress={closeFrecuentePopup}>
        <Text style={visitantesStyles.closeButtonText}>X</Text>
      </TouchableOpacity>
      <Ionicons name="checkmark-circle" size={30} color="#28a745" style={visitantesStyles.checkIcon} />
      <Text style={visitantesStyles.popupTitle}>Visitante frecuente registrado correctamente</Text>
      <Text style={visitantesStyles.popupMessage}>
        El visitante ha sido añadido a tu lista de frecuentes.
      </Text>
    </View>
  </Modal>

  <Modal isVisible={isAutorizarPopupVisible} onBackdropPress={closeAutorizarPopup} style={visitantesStyles.modal}>
    <View style={visitantesStyles.popupContainer}>
      <TouchableOpacity style={visitantesStyles.closeButton} onPress={closeAutorizarPopup}>
        <Text style={visitantesStyles.closeButtonText}>X</Text>
      </TouchableOpacity>
      <Ionicons name="checkmark-circle" size={30} color="#28a745" style={visitantesStyles.checkIcon} />
      <Text style={visitantesStyles.popupTitle}>Visitante autorizado con éxito</Text>
      <Text style={visitantesStyles.popupMessage}>
        El ingreso ha sido aprobado. El visitante debe presentar su cédula en la portería.
      </Text>
    </View>
  </Modal>
</View>
);
}

