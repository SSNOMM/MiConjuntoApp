import { View, Text, Image, TouchableOpacity, ScrollView } from "react-native";
import styles from "../assets/Styles/HomeStyles";
import { router } from "expo-router";

export default function Home() {
  return (
    <View style={{ flex: 1, backgroundColor: "#2d7dca" }}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.appName}>Mi Conjunto</Text>
          <Text style={styles.welcomeText}>¡Hola Laura!</Text>
        </View>
        <Image
          source={require("../assets/images/LogoBlanco.png")}
          style={styles.logo}
          resizeMode="contain"
        />
      </View>

      {/* Contenido principal */}
      <ScrollView contentContainerStyle={{ paddingBottom: 100 }}>
        <View style={styles.seccion}>
          {/* Comunicados */}
          <Text style={styles.titulo}>Comunicados</Text>
          <View style={styles.tarjeta}>
            <Text style={styles.fecha}>
              20/04/2025 <Text style={{ color: "green" }}>●</Text>
            </Text>
            <Text style={styles.subtitulo}>Jornada de Reciclaje Comunitario</Text>
            <Text style={styles.descripcion}>
              Sábado 20 de abril a las 10:00 a.m. Torre 3
            </Text>
            <Image
              source={require("../assets/images/ConjuntoFoto.png")}
              style={{ width: "100%", height: 100, marginTop: 10, borderRadius: 10 }}
              resizeMode="cover"
            />
            <TouchableOpacity
              style={styles.botonMas}
              onPress={() => router.push("Mantenimiento")}
            >
              <Text style={{ color: "white", fontSize: 22 }}>+</Text>
            </TouchableOpacity>
          </View>

          {/* Trámites */}
          <Text style={styles.titulo}>Trámites</Text>
          <View style={styles.tarjeta}>
            <Text style={styles.alerta}>¡22/04/2025!</Text>
            <Text style={styles.descripcion}>Último plazo pago administración</Text>
            <Text style={styles.valor}>$400.000</Text>
            <TouchableOpacity
              style={styles.botonAccion}
              onPress={() => router.push("Mantenimiento")}
            >
              <Text style={styles.textoBoton}>Pagar Ahora</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.botonMas}
              onPress={() => router.push("Mantenimiento")}
            >
              <Text style={{ color: "white", fontSize: 22 }}>+</Text>
            </TouchableOpacity>
          </View>

          {/* Visitantes */}
          <Text style={styles.titulo}>Visitantes</Text>
          <View style={styles.tarjeta}>
            <Text style={styles.descripcion}>¡Visitante anunciado en Portería!</Text>
            <TouchableOpacity
              style={styles.botonAccion}
              onPress={() => router.push("visitantes")}
            >
              <Text style={styles.textoBoton}>Permitir Ingreso</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.botonMas}
              onPress={() => router.push("visitantes")}
            >
              <Text style={{ color: "white", fontSize: 22 }}>+</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      {/* Menú inferior */}
      <View style={styles.menuInferior}>
       
        <TouchableOpacity onPress={() => router.push("Mantenimiento")}>
          <Image
            source={require("../assets/images/Chat.png")}
            style={styles.iconoMenu}
          />
        </TouchableOpacity> 
        <TouchableOpacity onPress={() => router.push("Home")}>
          <Image
            source={require("../assets/images/Home.png")}
            style={styles.iconoMenu}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => router.push("Mantenimiento")}>
          <Image
            source={require("../assets/images/Porfile.png")}
            style={styles.iconoMenu}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}
