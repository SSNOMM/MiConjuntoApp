import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import styles from '../assets/Styles/CorreoVreg';  // Importar estilos desde CorreoVreg

const Verificacion = () => {
  const router = useRouter();

  return (
    <View style={styles.containerC}>

        <Image source={require("../assets/images/Encabezado.png")} style={styles.logoC} />


      <View style={styles.messageContainerC}>
        <Text style={styles.textC}>
          Hemos enviado un mensaje de verificación a tu correo.
        </Text>


        <Text style={styles.textC}>
          Por favor, revisa tu bandeja de entrada (y la carpeta de spam) y haz clic en el enlace para activar tu cuenta.
        </Text>

        <Text style={styles.textC}>
          Una vez confirmes tu correo, podrás iniciar sesión y comenzar a usar Sintegra.
        </Text>

        <Text style={styles.resendTextC}>
          ¿No recibió un correo? <Text style={styles.resendLinkC}>Reenviar</Text>
        </Text>

        <View style={styles.buttonContainerC}>
          <TouchableOpacity
            style={styles.backButtonC}
            onPress={() => router.push('Registro')}
          >
            <Text style={styles.backTextC}>Volver</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.continueButtonC}
            onPress={() => router.push('Login')}
          >
            <Text style={styles.continueTextC}>Continuar</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default Verificacion;
