import { useRouter } from "expo-router";
import { useState } from "react";
import { Image, Text, TextInput, TouchableOpacity, View } from "react-native";
import loginStyles from "../assets/Styles/LoginStyles";

export default function Login() {
  const router = useRouter();

  const [correo, setCorreo] = useState('');
  const [contraseña, setContraseña] = useState('');

  const handleLogin = async () => {
    if (!correo || !contraseña) {
      alert('Campos incompletos', 'Por favor completa los campos obligatorios');
      return;
    }

    try {
      const res = await fetch('http://localhost:8080/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          correo: correo,
          contraseña: contraseña
        }),
      });
      const data = await res.json();

      if (res.ok) {
        alert('Éxito', 'Login exitoso');
        router.push("Home");
      } else {
        alert('VaLENTINA TONTA', data.error || 'Error al loguear');
      }
    } catch (error) {
      console.error('Error en logueo:', error);
      alert('Error', 'No se pudo conectar con el servidor');
    }
  };
  
  return (
    <View style={loginStyles.globalContainerLogin}>
      <Image
        source={require("../assets/images/Perfil.png")}
        style={loginStyles.profileImage}
      />

      <Text style={loginStyles.text}>Usuario</Text>
      <TextInput
        placeholder=""
        value={correo} onChangeText={setCorreo}
        style={loginStyles.inputLogin}
        placeholderTextColor="#888"
      />

      <Text style={loginStyles.text}>Contraseña</Text>
      <TextInput
        placeholder=""
        value={contraseña} onChangeText={setContraseña}
        secureTextEntry={true}
        style={loginStyles.passwordInputLogin}
        placeholderTextColor="#888"
      />

      <TouchableOpacity onPress={() => router.push("VerCorreo")}>
        <Text style={loginStyles.forgotTextLogin}>¿Olvidó su contraseña?</Text>
      </TouchableOpacity>

      <TouchableOpacity
  style={loginStyles.buttonBlueLogin}
  onPress={() => handleLogin()}
>
  <Text style={[loginStyles.buttonTextLogin, loginStyles.buttonTextWhiteLogin]}>
    Iniciar Sesión
  </Text>
</TouchableOpacity>


      <Text style={loginStyles.registerTextLogin}>
        ¿No tienes Cuenta?{" "}
        <Text
          style={loginStyles.registerLinkLogin}
          onPress={() => router.push("Registro")}
        >
          Regístrate
        </Text>
      </Text>
    </View>
  );
}
