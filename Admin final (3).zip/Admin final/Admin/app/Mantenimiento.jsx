import React from "react";
import { View, Text, Image, StyleSheet, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import MantenimientoS from "../assets/Styles/MantenimientoS";

export default function Mantenimiento() {
const router = useRouter();

return (
<View style={MantenimientoS.container}>

<Image
source={require("../assets/images/Encabezado.png")}
style={MantenimientoS.icono}
resizeMode="contain"
/>


  <View style={MantenimientoS.mensaje}>
    <Text style={MantenimientoS.titulo}>¡Estamos trabajando en ello!</Text>
    <Text style={MantenimientoS.descripcion}>
      Nuestra Aplicación está en su mantenimiento periódico por lo que algunas funciones no
      sirven por el momento, prometemos terminar pronto{"\n\n"}¡Gracias por tu paciencia!
    </Text>
  </View>

  <View style={MantenimientoS.menuInferior}>
    <TouchableOpacity onPress={() => router.push("/tramites")}>
      <Image
        source={require("../assets/images/Chat.png")}
        style={MantenimientoS.iconoMenu}
      />
    </TouchableOpacity>
    <TouchableOpacity onPress={() => router.push("Home")}>
      <Image
        source={require("../assets/images/Home.png")}
        style={[MantenimientoS.iconoMenu, MantenimientoS.iconoMenuActivo]}
      />
    </TouchableOpacity>
    <TouchableOpacity onPress={() => router.push("/perfil")}>
      <Image
        source={require("../assets/images/Porfile.png")}
        style={MantenimientoS.iconoMenu}
      />
    </TouchableOpacity>
  </View>
</View>
);
}