import { useRouter } from "expo-router";
import { useState } from "react";
import { Alert, Image, ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";
import RegistroStyles from "../assets/Styles/RegistroStyles";

function Registro() {
  const router = useRouter();
  const [aceptaNotificaciones, setAceptaNotificaciones] = useState(false);

  // Estados para los campos
  const [nombreDueno, setNombreDueno] = useState('');
  const [noTorre, setNoTorre] = useState('');
  const [noApto, setNoApto] = useState('');
  const [nombreCompleto, setNombreCompleto] = useState('');
  const [cc, setCc] = useState('');
  const [telefono, setTelefono] = useState('');
  const [correo, setCorreo] = useState('');
  const [contraseña, setContraseña] = useState('');
  const [confirmarContraseña, setConfirmarContraseña] = useState('');

  const toggleCheckbox = () => {
    setAceptaNotificaciones(!aceptaNotificaciones);
  };

  const handleRegistro = async () => {
    if (!correo || !contraseña || !nombreCompleto) {
      Alert.alert('Campos incompletos', 'Por favor completa los campos obligatorios');
      return;
    }

    if (contraseña !== confirmarContraseña) {
      Alert.alert('Error', 'Las contraseñas no coinciden');
      return;
    }

    try {
      const res = await fetch('http://localhost:8080/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nombre: nombreCompleto,
          correo: correo,
          contraseña: contraseña
        }),
      });
      const data = await res.json();

      if (res.ok) {
        Alert.alert('Éxito', 'Registro exitoso');
        router.push("Login");
      } else {
        Alert.alert('Error', data.error || 'Error al registrar');
      }
    } catch (error) {
      console.error('Error en registro:', error);
      Alert.alert('Error', 'No se pudo conectar con el servidor');
    }
  };

  return (
    <ScrollView contentContainerStyle={RegistroStyles.Globalcontainer}>
      <View style={RegistroStyles.container}>
        {/* Elipse de fondo */}
        <View style={RegistroStyles.topEllipse} />

        {/* Imagen perfil sobre la elipse */}
        <Image
          source={require("../assets/images/Perfil.png")}
          style={RegistroStyles.profileImage}
        />
        <Text style={RegistroStyles.title}>Foto de Perfil</Text>

        <Text style={RegistroStyles.label}>Nombre Dueño/a Apartamento</Text>
        <TextInput style={RegistroStyles.input} value={nombreDueno} onChangeText={setNombreDueno} />

        <View style={RegistroStyles.inputsTorres}>
          <View style={RegistroStyles.inputGroup}>
            <Text style={RegistroStyles.labelSmall}>No Torre</Text>
            <TextInput
              style={RegistroStyles.inputtorre}
              value={noTorre}
              onChangeText={setNoTorre}
              keyboardType="numeric"
            />
          </View>

          <View style={RegistroStyles.inputGroup}>
            <Text style={RegistroStyles.labelSmall}>No Apto</Text>
            <TextInput
              style={RegistroStyles.inputapto}
              value={noApto}
              onChangeText={setNoApto}
              keyboardType="numeric"
            />
          </View>
        </View>

        <Text style={RegistroStyles.label}>Nombre Completo</Text>
        <TextInput style={RegistroStyles.input} value={nombreCompleto} onChangeText={setNombreCompleto} />

        <Text style={RegistroStyles.label}>C.C</Text>
        <TextInput style={RegistroStyles.input} value={cc} onChangeText={setCc} keyboardType="numeric" />

        <Text style={RegistroStyles.label}>Teléfono</Text>
        <TextInput style={RegistroStyles.input} value={telefono} onChangeText={setTelefono} keyboardType="phone-pad" />

        <Text style={RegistroStyles.label}>Correo Electrónico</Text>
        <TextInput style={RegistroStyles.input} value={correo} onChangeText={setCorreo} keyboardType="email-address" />

        <View style={RegistroStyles.checkboxContainer}>
          <TouchableOpacity onPress={toggleCheckbox} style={RegistroStyles.checkbox}>
            {aceptaNotificaciones && (
              <View style={RegistroStyles.checkboxChecked} />
            )}
          </TouchableOpacity>
          <Text style={RegistroStyles.checkboxLabel}>
            Confirmo que deseo recibir notificaciones por medio del correo electrónico
          </Text>
        </View>

        <Text style={RegistroStyles.label}>Contraseña</Text>
        <TextInput style={RegistroStyles.input} secureTextEntry value={contraseña} onChangeText={setContraseña} />

        <Text style={RegistroStyles.label}>Confirmar Contraseña</Text>
        <TextInput style={RegistroStyles.input} secureTextEntry value={confirmarContraseña} onChangeText={setConfirmarContraseña} />

        <View style={RegistroStyles.row}>
          <TouchableOpacity style={[RegistroStyles.button, RegistroStyles.buttonGrey]} onPress={() => router.push("Login")}>
            <Text style={RegistroStyles.buttonText}>Volver</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[RegistroStyles.button, RegistroStyles.buttonBlue]} onPress={() => router.push("Verificacion")}>
            <Text style={[RegistroStyles.buttonText, RegistroStyles.buttonTextWhite]}>Registrarse</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

export default Registro;


