// app/index.jsx
import { useRouter } from 'expo-router';
import { Image, TouchableOpacity, View } from 'react-native';
import globalStyles from '../assets/Styles/GlobalStyles';

export default function Home() {
  const router = useRouter();

  return (
    <View style={globalStyles.container}>
      <TouchableOpacity onPress={() => router.push('Login')}>
        <Image
          source={require('../assets/images/LogoCon.png')} // Ajusta la ruta según el nombre de tu imagen
          style={globalStyles.imagencarga}
          resizeMode="contain"
        />
      </TouchableOpacity>
    </View>
  );
}
