// components/VerCorreo.jsx
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image } from 'react-native';
import { useRouter } from 'expo-router';
import CamConCo from '../assets/Styles/CamConCo';

const VerCorreo = () => {
  const [email, setEmail] = useState('');
  const router = useRouter();

  const handleSendEmail = () => {
    console.log(`Enviando correo a: ${email}`);
    router.push('/VerContrasena'); // Ir a cambiar contraseña
  };

  const handleGoBack = () => {
    router.replace('/Login'); // Volver a Login
  };

  return (
    <View style={CamConCo.container}>
      <Image
        source={require('../assets/images/Encabezado.png')} // ✅ Imagen de la elipse con logo
        style={CamConCo.headerImage}
      />

      <Text style={CamConCo.instructionText}>
        Ingrese el correo registrado con la cuenta
      </Text>

      <TextInput
        style={CamConCo.input}
        placeholder="Correo electrónico"
        placeholderTextColor="#999"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />

      <TouchableOpacity style={CamConCo.buttonSend} onPress={handleSendEmail}>
        <Text style={CamConCo.buttonText}>Enviar correo de Confirmación</Text>
      </TouchableOpacity>

      <TouchableOpacity style={CamConCo.buttonBack} onPress={handleGoBack}>
        <Text style={CamConCo.buttonTextB}>Volver</Text>
      </TouchableOpacity>
    </View>
  );
};

export default VerCorreo;


