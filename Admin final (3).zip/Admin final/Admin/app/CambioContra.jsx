// components/CambiarContrasena.jsx
import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text, Image } from 'react-native';
import { useRouter } from 'expo-router';
import CamContra from '../assets/Styles/CamContra';

const CambiarContrasena = () => {
  const [nueva, setNueva] = useState('');
  const [confirmar, setConfirmar] = useState('');
  const router = useRouter();

  const handleContinuar = () => {
    if (nueva === confirmar && nueva.length >= 6) {
      console.log('Nueva contraseña:', nueva);
      router.push('/Login');
    } else {
      alert('Las contraseñas no coinciden o son muy cortas.');
    }
  };

  return (
    <View style={CamContra.container}>
      <Image
        source={require('../assets/images/Encabezado.png')} // Imagen con fondo azul + logo
        style={CamContra.headerImage}
      />

      <TextInput
        style={CamContra.input}
        placeholder="Contraseña Nueva"
        secureTextEntry
        value={nueva}
        onChangeText={setNueva}
        placeholderTextColor="#555"
      />

      <TextInput
        style={CamContra.input}
        placeholder="Confirmar Contraseña"
        secureTextEntry
        value={confirmar}
        onChangeText={setConfirmar}
        placeholderTextColor="#555"
      />

      <TouchableOpacity style={CamContra.button} onPress={handleContinuar}>
        <Text style={CamContra.buttonText}>Continuar</Text>
      </TouchableOpacity>
    </View>
  );
};

export default CambiarContrasena;
